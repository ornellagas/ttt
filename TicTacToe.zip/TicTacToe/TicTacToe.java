import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.concurrent.*;
import javax.swing.*;

public class TicTacToe implements ActionListener {
	Random random;
	JFrame frame;
	JPanel title_panel;
	JPanel button_panel;
	JLabel textfield;
	JButton[] buttons;

	JButton startBtn;
	boolean player1_turn;

	TicTacToe(){
		init();
		initApp();
		openMenu(); // open main menu
	 }

	 public void init() {
		 random = new Random();
		 frame = new JFrame();
		 title_panel = new JPanel();
		 button_panel = new JPanel();
		 textfield = new JLabel();
		 buttons = new JButton[100];

		 startBtn = new JButton();
	 }

	 public void initApp() {
		 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 frame.setSize(1000,1000);
		 frame.getContentPane().setBackground(new Color(80,80,80));
		 frame.setLayout(new BorderLayout());
		 frame.setVisible(true);

		 textfield.setBackground(new Color(15,0,15));
		 textfield.setForeground(new Color(120,120,120));
		 textfield.setFont(new Font("Arial",Font.BOLD,60));
		 textfield.setHorizontalAlignment(JLabel.CENTER);
		 textfield.setText("Tic-Tac-Toe");
		 textfield.setOpaque(true);

		 title_panel.setLayout(new BorderLayout());
		 title_panel.setBounds(0,0,800,100);

		 button_panel.setLayout(new GridLayout(10,10));
		 button_panel.setBackground(new Color(10,10,10));
	 }

	public void openMenu() {

		startBtn.setBackground(Color.white);
		startBtn.setFont(new Font("Arial",Font.BOLD,50));
		startBtn.setFocusable(false);
		startBtn.addActionListener(this);
		startBtn.setText("Start Tic-Tac-Toe Game");
		frame.add(startBtn);
	}

	public void startGame() {
		for(int i=0;i<100;i++) {
			buttons[i] = new JButton();
			buttons[i].setBackground(Color.white);
			button_panel.add(buttons[i]);
			buttons[i].setFont(new Font("Arial",Font.BOLD,50));
			buttons[i].setFocusable(false);
			buttons[i].addActionListener(this);
		}

		title_panel.add(textfield);
		frame.add(title_panel,BorderLayout.NORTH);
		frame.add(button_panel);

		firstTurn();
	}

	public void restart() {
		init();
		initApp();
		openMenu();
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource().equals(startBtn)) { // if btn was clicked
			frame.remove(startBtn);
			startGame(); // start game
			return; // return
		}

		for(int i=0;i<100;i++) {
			if(!e.getSource().equals(buttons[i])) {
				continue;
			}
			if (!buttons[i].getText().equals("")) {
				return;
			}

			if(player1_turn) {
				buttons[i].setForeground(new Color(40,70,90));
				buttons[i].setText("X");
				player1_turn=false;
				textfield.setText("O");
				wincheck();
			} else {
				buttons[i].setForeground(new Color(90,20,40));
				buttons[i].setText("O");
				player1_turn=true;
				textfield.setText("X");
				wincheck();
			}
		}
	}
	
	public void firstTurn() {
		if(random.nextInt(2)==0) {
			player1_turn=true;
			textfield.setText("X");
			return;
		}
		player1_turn=false;
		textfield.setText("O");

	}

	public void wincheck() {

		for (int y = 0; y < 10; y++) {
			for (int x = 0; x < 10; x++) {
				int btnNum = y*10 + x;
				try {
					if (buttons[btnNum].getText().equals(buttons[btnNum + 1].getText()) && buttons[btnNum + 1].getText().equals(buttons[btnNum + 2].getText()) && !buttons[btnNum].getText().equals(""))
					{
						System.out.println("yes");
						win(buttons[btnNum].getText(), btnNum, btnNum+1, btnNum+2);
						return;
					}
					if (buttons[btnNum].getText().equals(buttons[btnNum + 10].getText()) && buttons[btnNum + 10].getText().equals(buttons[btnNum + 20].getText()) && !buttons[btnNum].getText().equals(""))
					{
						System.out.println("yes");
						win(buttons[btnNum].getText(), btnNum, btnNum+10, btnNum+20);
						return;
					}
					if (buttons[btnNum].getText().equals(buttons[btnNum + 11].getText()) && buttons[btnNum + 11].getText().equals(buttons[btnNum + 22].getText()) && !buttons[btnNum].getText().equals(""))
					{
						System.out.println("yes");
						win(buttons[btnNum].getText(), btnNum, btnNum+11, btnNum+22);
						return;
					}
					if (buttons[btnNum].getText().equals(buttons[btnNum + 9].getText()) && buttons[btnNum + 9].getText().equals(buttons[btnNum + 18].getText()) && !buttons[btnNum].getText().equals(""))
					{
						System.out.println("yes");
						win(buttons[btnNum].getText(), btnNum, btnNum+9, btnNum+18);
						return;
					}
				} catch (Exception e) {
					//
				}
			}
		}

	}

	public void win(String side, int a,int b,int c) {
		buttons[a].setBackground(Color.GREEN);
		buttons[b].setBackground(Color.GREEN);
		buttons[c].setBackground(Color.GREEN);

		for(int i=0;i<100;i++) {
			buttons[i].setEnabled(false);
		}
		textfield.setText(side+" wins");

		final ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
		Runnable runnable = () -> {
			restart();
			executorService.shutdown();
		};

		executorService.scheduleWithFixedDelay(runnable, 2, 1, TimeUnit.SECONDS);

	}
}